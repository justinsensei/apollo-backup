---
name: obsidian-vault-hygiene
description: Audit and repair Justin's Obsidian vault — detect misplaced notes, missing or malformed frontmatter, and category drift. Use when Justin asks about vault hygiene, note organization, or automated vault maintenance jobs.
platforms: [linux]
related_skills: [obsidian, obsidian-people-notes, manage-projects]
---

# Obsidian Vault Hygiene

Use this skill when Justin asks to audit, clean up, or automate maintenance of his Obsidian vault. Always load the base `obsidian` skill too for vault path and file-tool conventions.

Vault path: `/home/justin.guest/vault`

## What to check (and what to skip)

### Check these areas

| Folder | What to check |
|--------|---------------|
| `Notebook/` | Missing `category:`, misplaced daily notes, blank `category:` fields |
| Vault root | Non-daily-note, non-project files that shouldn't be there |
| `References/` | Missing `id` or `daily_note` |
| `Categories/` | Missing `category: "[[Categories]]"` field |
| `Granola/` | Missing `category: "[[Meetings]]"` on summaries (`type: note` or legacy format with no type field). Skip transcripts (`type: transcript`). |

### Skip these — third-party managed, own schemas

- `Readwise/` — Readwise plugin. Fields: `id` (non-standard), `daily_note` (plain string not wikilink). Do NOT patch — overwritten on next sync.
- `Templates/` — Contains Templater syntax. Never auto-edit.
- `Daily Notes/` — `daily_note` backfill is low-value; skip.
- `.trash/`, `.cursor/`, `.claude/` — Ignore.
- `Granola/` — Skip general walk checks (ID conflicts, missing `id`, missing `daily_note`) as it uses its own schema, but scan specifically for the Meetings category check as noted above.

## Key checks

### 1. Misplaced daily notes in Notebook/

Detection heuristic:
- Filename matches `YYYY-MM-DD (Monday|Tuesday|Wednesday|Thursday|Friday|Saturday|Sunday).md`
- No topic words after the weekday
- Contains `#daily_note` tag OR `id:` frontmatter matching the date

Correct location: `Daily Notes/`. Move, don't delete.

Known instances as of 2026-05-22 (may have grown):
```
Notebook/2026-05-20 Wednesday.md
Notebook/2026-05-19 Tuesday.md
Notebook/2026-05-18 Monday.md
Notebook/2026-03-17 Tuesday.md
Notebook/2025-10-01 Wednesday.md
```

### 2. Missing category in Notebook

Run:
```bash
grep -rL '^category:' /home/justin.guest/vault/Notebook --include='*.md'
```

Also catch blank category:
```bash
grep -r '^category:$' /home/justin.guest/vault/Notebook --include='*.md'
grep -r '^category: $' /home/justin.guest/vault/Notebook --include='*.md'
```

Classification heuristics for uncategorized Notebook notes:

| Condition | Likely category |
|-----------|----------------|
| `#project` tag | `"[[Projects]]"` |
| `#reference` tag | `"[[References]]"` (new category, not yet defined — flag for Justin) |
| `#trip` tag | No category yet — flag |
| filename looks like `YYYY-MM-DD Weekday.md` | Misplaced daily note — move, don't categorize |
| Essay/journal content | No category yet — flag |

The Tier 1 / Tier 2 split (auto-fix vs. report-only):
- **Auto-fix**: move misplaced daily notes, fill in `category: "[[Projects]]"` for `#project`-tagged notes
- **Report only**: everything else — present grouped by likely type so Justin can decide

### 3. Malformed id field

Valid format: `id: "YYYYMMDDHHmmss"` (14 numeric digits, optionally single-quoted).

Detect bad format:
```bash
grep -r '^id:' /home/justin.guest/vault/Notebook --include='*.md' \
  | grep -v "'[0-9]\{14\}'" \
  | grep -v '"[0-9]\{14\}"'
```

Skip Readwise and Granola (known non-standard).

### 4. Project note location

Project notes (`category: "[[Projects]]"`) belong in **vault root**, not `Notebook/`. This is intentional — see `manage-projects` skill. Don't flag these as misplaced.

## Hygiene job design (implemented, May 2026)

The job is fully automated as a script-only cron job in Hermes:
- **Name**: `vault-hygiene`
- **Schedule**: `0 8 * * *` (8:00 AM daily)
- **Mode**: `no_agent: true` (watchdog pattern — silent unless issues found)
- **Script**: `vault_hygiene_cron.py` (resolves to `/home/justin.guest/.hermes/scripts/vault_hygiene_cron.py`)

**Path Resolution Pitfall**: Under Hermes, relative paths for cron scripts resolve directly relative to `~/.hermes/scripts/`. Setting `script: ".hermes/scripts/vault_hygiene_cron.py"` will fail because it resolves to `~/.hermes/scripts/.hermes/scripts/...`. Always use the bare filename `vault_hygiene_cron.py`.

Two tiers implemented:

**Tier 1 — auto-fix (runs silently under vault_hygiene.py):**
- Move misplaced daily notes from `Notebook/` to `Daily Notes/`
- Fill blank `category:` fields with `"[[Projects]]"` for `#project`-tagged notes
- Add `category: "[[Meetings]]"` to Granola summaries missing it (skipping transcripts)

**Tier 2 — report (stdout printed only on red-level issues):**
- Notebook notes missing `category:` grouped by heuristic type
- Notes with malformed `id` (outside Granola/Readwise)
- ID conflicts, missing IDs, missing daily_note links.
- If there are red-level errors, `vault_hygiene_cron.py` prints them and exits, causing a Telegram alert. Otherwise, it stays completely silent.

**Delivery**: Telegram message with grouped summary. Keep it scannable — use bullet lists, not tables.

## Pitfalls

1. **Don't touch Readwise, and only touch Granola for the Meetings category check.** Readwise notes are completely overwritten on sync. Granola notes are also managed externally, but we safely backfill `category: "[[Meetings]]"` on summaries (`type: note` or no type field) while ignoring transcripts. Do not perform any other frontmatter edits (like adding numeric `id` or `daily_note`) on Granola files.
2. **Don't run git commands.** `bes-vault-sync` watcher auto-commits within seconds of any write.
3. **Blank `category:` ≠ missing `category:`.** `grep -L` misses notes that have the field but no value. Check both.
4. **`YYYY-MM-DD Title.md` ≠ daily note.** Only `YYYY-MM-DD Weekday.md` (day name only, no topic) are misplaced daily notes. Meeting notes are `YYYY-MM-DD Topic.md` and belong in `Notebook/`.
5. **Project notes live in root.** Don't move `Bes Setup.md` or any `category: "[[Projects]]"` note — vault root is correct for them.

## References

- `references/vault-audit-2026-05-22.md` — full audit from first hygiene session: folder sizes, category distribution, known issues, full list of uncategorized notes.
