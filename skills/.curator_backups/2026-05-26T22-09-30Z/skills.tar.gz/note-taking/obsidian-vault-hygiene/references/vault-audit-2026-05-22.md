# Vault Audit — 2026-05-22

Full structural and frontmatter audit of `/home/justin.guest/vault`.

## Vault size

| Folder | Files |
|--------|-------|
| Notebook/ | 324 |
| Daily Notes/ | 228 (archived) |
| Granola/ | 52 (summaries + transcripts) |
| Readwise/ | 112 |
| References/ | 38 |
| Templates/ | 7 |
| Root | 2 (today's daily note + Bes Setup.md) |
| **Total** | ~796 |

## Notebook breakdown

| Type | Count |
|------|-------|
| category: [[Meetings]] | 148 |
| category: [[People]] | 149 |
| category: [[Organizations]] | 1 |
| No category field | 25 |

- 153 notes are date-prefixed (`YYYY-MM-DD Title`) — meeting notes, correctly in Notebook.
- 171 notes have no date prefix — mix of People, Orgs, and uncategorized.

## Issues

### 1. Misplaced daily notes in Notebook/ (5 files)

Files named `YYYY-MM-DD Weekday.md` (no topic after day name) in `Notebook/` instead of `Daily Notes/`:

```
Notebook/2026-05-20 Wednesday.md
Notebook/2026-05-19 Tuesday.md
Notebook/2026-05-18 Monday.md
Notebook/2026-03-17 Tuesday.md
Notebook/2025-10-01 Wednesday.md
```

### 2. Notebook notes missing category (25 files)

Full list with apparent type:

```
# Likely [[Projects]] (#project tag)
AI Agents 2026 H1.md
Mobile Game Doctors.md

# Likely [[References]] (#reference tag — category not yet defined)
ASL Facts.md
Benchmarks - notification opt-in rate.md
Benchmarks - Subscription page CTR.md
Benchmarks - user retention.md

# Trip notes (#trip tag — no category defined)
Madeira 2026.md
Belize 2026.md

# Blank category: field (has key, no value)
Headaches 20260520142723.md

# Essays / journals (no clear category)
Sports fandom sucks 20260423102157.md
Fighting with Jamie 20260519075445.md
Brain dump on Bes 20260519162610.md
The Beginning of Infinity 20260506092057.md
Spring Performance 20260501134243.md
PostHog → CustomerIO 20260423101926.md
Single-agent for Clio for now 20260519111334.md
Response to Tor's thoughts on Artemis 20260514081149.md
Bot thoughts - Clio vs Artemis 20260513091336.md
Cursor on Agent-Powered Dev 20260513084557.md
Tor's thoughts about Artemis-style code bots 20260514080631.md
Dianne AI Workshop 20260420141613.md

# Misplaced daily notes (move, don't categorize)
2026-05-20 Wednesday.md
2026-05-19 Tuesday.md
2026-05-18 Monday.md
2026-03-17 Tuesday.md
2025-10-01 Wednesday.md
```

### 3. Bes Setup.md in vault root

Sole `category: "[[Projects]]"` note. This is INTENTIONAL — project notes live in vault root per manage-projects convention.

### 4. Readwise bulk import bug (all 112 files)

All imported in one batch with:
- `id: "2026052211:53 AM"` (should be YYYYMMDDHHmmss)
- `daily_note: "2026-05-22 Friday"` (plain string, not wikilink)

Do NOT patch. Plugin-managed, will be overwritten on next sync. Fix belongs in Readwise import template/settings.

### 5. Daily Notes missing daily_note field

Many archived notes predate the `daily_note` convention. Low priority — filename is the date reference. Not worth backfilling.

## Open questions (as of 2026-05-22, unanswered)

1. Should a `[[References]]` category be created for reference/benchmark notes?
2. Should `[[Notes]]` or `[[Essays]]` be created for journal-type content?
3. Trip notes — new `[[Trips]]` category, or leave uncategorized?
4. Readwise import template — does Justin control it? Fix would resolve the id/daily_note format issues.
5. Hygiene job cadence — daily Telegram report, or on-demand only?
