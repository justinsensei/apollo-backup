---
name: morning-briefing
description: "Interactive morning briefing for Justin — runs after the 7AM cron has done background work (work log, vault hygiene Tier 1, inbox gather). Walks through a multi-phase conversation: work log highlights, calendar summary, near-term task triage, calendar inbox candidates, general inbox candidates. Load this skill whenever Justin responds to the morning greeting or asks for his morning briefing."
platforms: [linux]
related_skills: [work-log, todoist-inbox-fill, obsidian-vault-hygiene, todoist]
---

# 🌅 Morning Briefing

This skill governs the **interactive phase** of the morning briefing. The 7AM cron runs background jobs and sends a greeting; once Justin responds, load this skill and walk through the phases in order.

## Key files

- **Cache:** `~/.hermes/morning-briefing/YYYY-MM-DD.json` — written by cron, read here
- **Days off:** `~/.hermes/days-off.txt` — personal non-holiday days off
- **Work-day helper:** `python3.12 ~/.hermes/scripts/work_day.py <cmd> [date]`
- **Vault:** `/home/justin.guest/vault` (or `$OBSIDIAN_VAULT_PATH`)

## Entry point

The cron sends: *"Morning, Justin! Ready to start your day?"*

Justin's reply determines the flow:
- **"yes" / any affirmative** → full briefing (all phases)
- **"day off" / "taking the day off" / similar** → skip Phase 1; run Phases 2–5 with personal-only filter
- **no response within the session** → nothing; cron already ran background jobs

## Cache file schema

The 7AM cron writes `~/.hermes/morning-briefing/YYYY-MM-DD.json` with this structure:

```json
{
  "date": "YYYY-MM-DD",
  "is_work_day": true,
  "work_log_dates": ["YYYY-MM-DD"],
  "work_log_status": "ok | error | skipped",
  "vault_hygiene": {
    "tier1_status": "ok | error",
    "tier1_summary": "Moved 2 daily notes. Fixed 1 blank category.",
    "tier2_issues": [
      "Notebook/Some Note.md — missing category (looks like essay)",
      "Notebook/Other Note.md — malformed id field"
    ]
  },
  "inbox_candidates": {
    "status": "ok | error | partial",
    "sources_failed": [],
    "calendar_events": [...],
    "action_items": [...]
  }
}
```

If the cache file doesn't exist (cron failed or hasn't run yet), run the background jobs inline before proceeding. Tell Justin there'll be a brief pause.

## Phase sequence

### Phase 1 — Work log highlights

**Skip entirely if:** `is_work_day` is false OR Justin said "day off."

**If `is_work_day` is true:**

1. Load `work_log_dates` from cache (computed by cron using `work_day.py logs_to_summarize`)
2. For each date in `work_log_dates`, read the `# 📋 Work Log` section from the daily note in vault
3. Synthesize highlights across all dates into a single brief summary

**Format:**
```
📋 Work log — [Day, Mon DD] (or "Fri–Mon" for multi-day spans)

• [2–4 bullet highlights — most important things that happened]
• Decisions: [1–2 if any, otherwise omit]
• Still open: [1–2 blockers/open questions, if any]
```

Keep it scannable. 4–6 bullets max. If multiple days, don't repeat obvious context — synthesize across them. Don't recite every meeting; surface the consequential ones.

If no work log entries exist for the dates (notes missing or no Work Log section), say so briefly and move on. Don't block on it.

After presenting, **wait for acknowledgment or a question** before moving to Phase 2. Don't immediately dump everything at once.

---

### Phase 2 — Calendar summary

Pull today's calendar and look ahead 7 days for anything major. Since the background cache file only stores *candidates* (events not yet on the calendar), you must fetch the actual scheduled events live.

**Sources:** Fetch live from Google Workspace across all accounts (or personal accounts only on non-work days):
- Work and personal: `python3 ~/.hermes/skills/productivity/google-workspace/scripts/gws_multi.py --account all calendar list`
- Personal only (weekends/days off): `python3 ~/.hermes/skills/productivity/google-workspace/scripts/gws_multi.py --account personal-main,personal-junk calendar list`

**Format:**
```
📅 Today — [Day, Mon DD]

• HH:MM  Event name (attendees if external)
• HH:MM  Event name
[if nothing: "Nothing on the calendar today."]

Coming up this week:
• [Day] Event name — [why it's notable: external attendees / prep needed / important]
[only surface 2–3 notable items, not every standup]
```

**On non-work days (or "day off"):** show personal calendar events only. Skip work account events.

After presenting, wait for acknowledgment before Phase 3.

---

### Phase 3 — Near-term task triage

Query Todoist for tasks with due dates or deadlines in the next 3 days (inclusive of today).

**Rule:** Skip any tasks that are already in the "Now" project, or completed/cancelled tasks.
Only present this if there are matching tasks. If none, skip directly to the next phase.

**Format:**
```
📌 N tasks due or with deadlines in the next 3 days:

1. [Project] Task name (due: Date/Time | deadline: Date)
...

Would you like to move any of these to "Now"?
```

Once Justin selects tasks, move them to the "Now" project.

After presenting and handling any movements, wait for acknowledgment before Phase 4.

---

### Phase 4 — Calendar inbox candidates

Present the calendar event candidates from `inbox_candidates.calendar_events`.

Suggest a target calendar (`work` or `personal-main`) for each candidate based on its source and content (e.g., family/school/personal tasks default to `personal-main`, while SignLab/professional ones default to `work`).

Format:
```
📅 N potential calendar events not yet on your calendar:

1. [Source] Event | when: date/time | calendar: work | context: where found
2. [Source] Event | when: date/time | calendar: personal-main | context: where found
...

Which ones should I add directly to your Google Calendar?
```

If `calendar_events` is empty, say "Nothing new to add to your calendar." and skip to Phase 5.

Once Justin confirms selections:
- Schedule/create the events directly on the respective Google Calendar accounts (`work` or `personal-main`) using the calendar write capabilities (`gws_multi.py --account <name> calendar create --summary ... --start ... --end ...`).
- Only create a Todoist "Add to calendar:" task as an exceptional fallback if Justin specifically requests it or if the event timing/date is too ambiguous to schedule directly.
- Report the scheduling confirmation with event details and links, then move to Phase 5.

**On non-work days / day off:** still run this phase but filter to personal events only (skip work Slack, work email sources).

---

### Phase 5 — Inbox candidates

Present the action-item candidates from `inbox_candidates.action_items`.

Use the format from `todoist-inbox-fill` Step 4 Section B — semantically batched groups:
```
📥 N potential inbox items:

**[Group label]**
1. [Source] Task description
2. [Source] Task description

**[Group label]**
3. ...

Which ones should I add?
```

If `action_items` is empty, say "Inbox looks clear." 

Once Justin confirms → batch-add to Todoist Inbox with comments.

**On non-work days / day off:** filter out work-sourced tasks (Linear, work email, work Slack). Keep home/family/personal ones.

---

### After all phases

If vault hygiene Tier 2 issues exist in the cache, append a brief report at the end:

```
🗂 Vault hygiene — N items to look at when you have a moment:
• Notebook/Some Note.md — missing category (looks like an essay)
• ...
```

Don't block on this or ask for immediate action. It's informational.

Then close out: *"That's everything. Have a good [day/weekend/Monday]."* (Match the day.)

---

## Work-day detection quick reference

```bash
# Is today a work day?
python3.12 ~/.hermes/scripts/work_day.py is_work_day

# Which dates' work logs to summarize today?
python3.12 ~/.hermes/scripts/work_day.py logs_to_summarize

# Previous work day
python3.12 ~/.hermes/scripts/work_day.py prev_work_day
```

US federal holidays auto-detected. Personal days off in `~/.hermes/days-off.txt` (one YYYY-MM-DD per line, # comments ok).

---

## Tone and pacing

- One phase per message. Don't dump everything at once.
- Wait for acknowledgment between phases. Justin may want to ask a question or act on something before moving on.
- Keep each phase message short. The briefing should feel like a quick check-in, not a wall of text.
- Match energy to day: Monday morning gets a slightly warmer opener; Friday gets a brief "anything to wrap up this week?" at the end if there are open blockers.
- On weekends / days off: lighter, shorter, personal focus only.

---

## Pitfalls

- **Child name or grade misattribution.** Do not guess or assume which child a school event (like a graduation, potluck, or class celebration) belongs to. Always verify school grades and ages against the user profile (e.g., Jamie is in 5th grade/G5, Sam is in 6th grade/G6) before writing descriptions or adding summaries.
- **Decision misattribution.** When summarizing work logs or calendar updates, do not attribute decisions made by others (colleagues, family members, teachers) to Justin. Always explicitly credit the actual decision-maker.
- **Don't re-run background jobs if the cache is fresh.** Check the cache first. Only re-run if the file is missing or >4h old.
- **Work log section header is `# 📋 Work Log`** in the daily note. If it's absent, the note may not have been logged yet — say so, don't silently skip.
- **Multiple work-log dates:** synthesize, don't concatenate. Justin doesn't want to read Friday's full log on Monday — he wants the 3-line version.
- **Calendar dedup is against the full 30-day snapshot** already in the cache. Don't re-fetch unless you need to.
- **"Day off" filter applies per-phase.** Check it before each phase, not just once at the top.
- **Vault hygiene is never blocking.** Always put it last, always frame it as "when you have a moment."
